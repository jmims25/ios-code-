# NewPass Privacy Policy

We don't store any of your personal information. Simple as that. We just don't need it. Enjoy creating your passwords!
